package com.radhikacab.faremeter

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val farePerKm = 25.0
    private val prefs by lazy { getSharedPreferences("trip_state", MODE_PRIVATE) }
    private lateinit var statusText: TextView
    private lateinit var distanceText: TextView
    private lateinit var fareText: TextView
    private lateinit var startButton: Button
    private lateinit var endButton: Button
    private lateinit var pdfButton: Button
    private var tracking = false
    private var totalMeters = 0.0
    private var startTime = ""
    private var endTime = ""
    private val requestCodeLocation = 101
    private val createPdfCode = 202
    private val requestCodeNotifications = 102

    private val tripReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            totalMeters = intent.getDoubleExtra("meters", totalMeters)
            tracking = prefs.getBoolean("tracking", false)
            if (intent.action == TripLocationService.ACTION_STOPPED) {
                endTime = now()
                statusText.text = "प्रवास पूर्ण • रोख रक्कम जमा करा"
            } else {
                statusText.text = "प्रवास सुरू आहे • Background GPS चालू"
            }
            refreshNumbers()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        restoreTripState()
        if (!hasFineLocationPermission()) requestLocationPermission()
        else requestNotificationPermission()
    }

    @Suppress("DEPRECATION")
    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(TripLocationService.ACTION_UPDATE)
            addAction(TripLocationService.ACTION_STOPPED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(tripReceiver, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(tripReceiver, filter)
        restoreTripState()
    }

    override fun onStop() {
        try { unregisterReceiver(tripReceiver) } catch (_: IllegalArgumentException) { }
        super.onStop()
    }

    private fun restoreTripState() {
        tracking = prefs.getBoolean("tracking", false)
        totalMeters = prefs.getFloat("total_meters", 0f).toDouble()
        startTime = prefs.getString("start_time", "") ?: ""
        endTime = prefs.getString("end_time", "") ?: ""
        if (tracking) statusText.text = "प्रवास सुरू आहे • Background GPS चालू"
        refreshNumbers()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 32, 28, 24)
            setBackgroundColor(0xFFF5F7F5.toInt())
        }
        fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
            TextView(this).apply {
                text = value; textSize = size; setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
            }
        root.addView(text("RADHIKA CAB", 27f, 0xFF123B2A.toInt(), true), lp(-1, -2, 0, 0, 0, 8))
        root.addView(text("GPS FARE METER", 14f, 0xFF5A6B60.toInt(), true), lp(-1, -2, 0, 0, 0, 24))
        root.addView(text("भाडे दर: ₹25 प्रति किलोमीटर", 19f, 0xFF167A45.toInt(), true), lp(-1, -2, 0, 0, 0, 20))
        statusText = text("प्रवास सुरू करण्यासाठी START दाबा", 15f, 0xFF34443A.toInt())
        root.addView(statusText, lp(-1, -2, 0, 0, 0, 20))
        root.addView(text("एकूण अंतर", 16f, 0xFF657269.toInt()), lp(-1, -2, 0, 0, 0, 4))
        distanceText = text("0.00 km", 38f, 0xFF17251C.toInt(), true)
        root.addView(distanceText, lp(-1, -2, 0, 0, 0, 16))
        root.addView(text("एकूण बिल", 16f, 0xFF657269.toInt()), lp(-1, -2, 0, 0, 0, 4))
        fareText = text("₹0.00", 34f, 0xFF167A45.toInt(), true)
        root.addView(fareText, lp(-1, -2, 0, 0, 0, 24))
        startButton = Button(this).apply {
            text = "START – प्रवास सुरू करा"; setTextColor(-1); setBackgroundColor(0xFF16834A.toInt())
            setOnClickListener { startTrip() }
        }
        endButton = Button(this).apply {
            text = "END – प्रवास समाप्त करा"; setTextColor(-1); setBackgroundColor(0xFFC0392B.toInt())
            setOnClickListener { endTrip() }
        }
        pdfButton = Button(this).apply {
            text = "PDF बिल डाउनलोड करा"; setOnClickListener { createPdf() }
        }
        root.addView(startButton, lp(-1, 56, 0, 0, 0, 12))
        root.addView(endButton, lp(-1, 56, 0, 0, 0, 12))
        root.addView(pdfButton, lp(-1, 56, 0, 0, 0, 20))
        root.addView(text("START केल्यानंतर स्क्रीन बंद असली किंवा दुसरे अॅप वापरले तरी Background GPS सुरू राहील. वर कायम सूचना दिसेल.", 12f, 0xFF657269.toInt()), lp(-1, -2, 0, 0, 0, 0))
        setContentView(root)
        updateButtons()
    }

    private fun lp(width: Int, height: Int, left: Int, top: Int, right: Int, bottom: Int) =
        LinearLayout.LayoutParams(width, height).apply { setMargins(left, top, right, bottom) }

    private fun hasFineLocationPermission() = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    private fun requestLocationPermission() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), requestCodeLocation)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestCodeLocation && !hasFineLocationPermission()) {
            Toast.makeText(this, "अचूक GPS साठी Allow precise location निवडा.", Toast.LENGTH_LONG).show()
        } else if (requestCode == requestCodeLocation) requestNotificationPermission()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), requestCodeNotifications)
        }
    }

    private fun startTrip() {
        if (!hasFineLocationPermission()) { requestLocationPermission(); return }
        if (tracking) return
        totalMeters = 0.0; startTime = now(); endTime = ""
        prefs.edit().putFloat("total_meters", 0f).putBoolean("tracking", true).putString("start_time", startTime).putString("end_time", "").commit()
        val serviceIntent = Intent(this, TripLocationService::class.java).setAction(TripLocationService.ACTION_START)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ContextCompat.startForegroundService(this, serviceIntent)
            else startService(serviceIntent)
            tracking = true
            statusText.text = "प्रवास सुरू आहे • Background GPS चालू"
            refreshNumbers()
        } catch (e: Exception) {
            prefs.edit().putBoolean("tracking", false).commit()
            tracking = false
            Toast.makeText(this, "GPS Service सुरू झाली नाही: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            updateButtons()
        }
    }

    private fun endTrip() {
        if (!tracking) return
        startService(Intent(this, TripLocationService::class.java).setAction(TripLocationService.ACTION_STOP))
        tracking = false
        totalMeters = prefs.getFloat("total_meters", 0f).toDouble()
        endTime = now()
        prefs.edit().putBoolean("tracking", false).putString("end_time", endTime).commit()
        showPaymentScreen()
    }

    private fun showPaymentScreen() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setBackgroundColor(0xFFF5F7F5.toInt()) }
        val green = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(24, 48, 24, 48); setBackgroundColor(0xFF078A3D.toInt()) }
        val km = totalMeters / 1000.0
        val amount = km * farePerKm
        val amountText = TextView(this).apply { text = String.format(Locale.US, "₹ %.2f", amount); textSize = 48f; setTextColor(-1); setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER }
        val payText = TextView(this).apply { text = "ग्राहकाकडून रोख रक्कम घ्या\nPAY IN CASH"; textSize = 20f; setTextColor(-1); gravity = Gravity.CENTER; setPadding(8, 28, 8, 8) }
        val distance = TextView(this).apply { text = String.format(Locale.US, "एकूण अंतर: %.2f km  |  दर: ₹25/km", km); textSize = 15f; setTextColor(0xFFE6F5EA.toInt()); gravity = Gravity.CENTER; setPadding(8, 20, 8, 0) }
        green.addView(amountText, lp(-1, -2, 0, 0, 0, 0)); green.addView(payText, lp(-1, -2, 0, 0, 0, 0)); green.addView(distance, lp(-1, -2, 0, 0, 0, 0))
        root.addView(green, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "PDF बिल डाउनलोड करा"; setOnClickListener { createPdf() } }, lp(-1, 54, 24, 18, 24, 10))
        root.addView(Button(this).apply { text = "CASH COLLECTED"; textSize = 18f; setTextColor(-1); setBackgroundColor(0xFF0878D1.toInt()); setOnClickListener {
            totalMeters = 0.0; tracking = false; startTime = ""; endTime = ""
            prefs.edit().clear().commit(); buildScreen(); Toast.makeText(this@MainActivity, "रोख रक्कम जमा झाली. नवीन प्रवास सुरू करू शकता.", Toast.LENGTH_SHORT).show()
        } }, lp(-1, 60, 24, 0, 24, 24))
        setContentView(root)
    }

    private fun updateButtons() {
        startButton.isEnabled = !tracking; endButton.isEnabled = tracking; pdfButton.isEnabled = !tracking && endTime.isNotBlank()
        startButton.alpha = if (startButton.isEnabled) 1f else .45f; endButton.alpha = if (endButton.isEnabled) 1f else .45f; pdfButton.alpha = if (pdfButton.isEnabled) 1f else .45f
    }
    private fun refreshNumbers() {
        distanceText.text = String.format(Locale.US, "%.2f km", totalMeters / 1000.0)
        fareText.text = String.format(Locale.US, "₹%.2f", totalMeters / 1000.0 * farePerKm)
        updateButtons()
    }
    private fun now() = SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale("en", "IN")).format(Date())

    private fun createPdf() {
        if (endTime.isBlank()) return
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"; putExtra(Intent.EXTRA_TITLE, "RadhikaCab_Bill_${System.currentTimeMillis()}.pdf") }
        startActivityForResult(intent, createPdfCode)
    }
    @Deprecated("Deprecated API retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == createPdfCode && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            try { contentResolver.openOutputStream(uri)?.use { writePdf(it) }; Toast.makeText(this, "PDF बिल सेव झाले.", Toast.LENGTH_LONG).show() }
            catch (e: Exception) { Toast.makeText(this, "PDF सेव करताना त्रुटी: ${e.localizedMessage}", Toast.LENGTH_LONG).show() }
        }
    }
    private fun writePdf(out: OutputStream) {
        val pdf = PdfDocument(); val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create()); val canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 20f }
        paint.textSize = 28f; paint.isFakeBoldText = true; canvas.drawText("RADHIKA CAB", 50f, 70f, paint)
        paint.textSize = 16f; paint.isFakeBoldText = false; canvas.drawText("GPS TRIP BILL", 50f, 105f, paint); canvas.drawLine(50f, 125f, 545f, 125f, paint)
        paint.textSize = 18f; val km = totalMeters / 1000.0
        val lines = listOf("Trip date: $startTime", "Trip ended: $endTime", String.format(Locale.US, "Distance: %.2f km", km), "Rate: Rs. 25.00 per km", String.format(Locale.US, "TOTAL FARE: Rs. %.2f", km * farePerKm))
        var y = 180f; for (line in lines) { canvas.drawText(line, 50f, y, paint); y += 48f }
        paint.textSize = 12f; canvas.drawText("Distance is calculated using device GPS. Actual accuracy may vary.", 50f, 500f, paint)
        pdf.finishPage(page); pdf.writeTo(out); pdf.close()
    }
}
